#include<stdio.h>
#include<stdlib.h>

typedef struct State {
	int *available;
	int *completed;
	int **max_resources;
	int **allocated;
	int **need;
} State;


int ** mat_alloc(int r, int c);
int check_safe_state(State state, int num_processes, int resource);
void print_state(State state, int num_processes, int resource);

State state, state_old;

int
  main(int argc, char ** argv) {
  int  instance, i, j, k, count1, count2;
  int num_processes, resource;
  FILE * fp;
  char comment[80];

    if (argc < 2){
    fprintf(stderr, "Syntax: %s filename\n", argv[0]);
    return 1;
  }
  
  if ((fp=fopen(argv[1], "r")) == NULL){
	fprintf(stderr, "Error opening file %s\n", argv[1]);
  }
  
  fscanf(fp, "%d %d", &num_processes, &resource);
  fgets(comment, sizeof(comment), fp);
 
// Allocation of data structures
  state.available = (int *) malloc(resource*sizeof(int)); 
  state.completed = (int *) malloc(num_processes*sizeof(int));
  state.max_resources = (int **) mat_alloc(num_processes, resource);
  state.allocated = (int **) mat_alloc(num_processes, resource);
  state.need = (int **) mat_alloc(num_processes, resource); 
  
  state_old = state;

  for(i=0;i<num_processes;i++)
    state.completed[i] = 0;

  printf("Enter No. of available instances\n");
  for(i=0;i<resource;i++) {
      fscanf(fp,"%d",&instance);
      state.available[i] = instance;
  } 
  fgets(comment, sizeof(comment), fp);
  printf("Enter Maximum num. of instances of resources that a process need:\n");
    for(i=0;i<num_processes;i++){
      printf("P[%d]\n",i);
      for(j=0;j<resource;j++){
        fscanf(fp, "%d",&instance);
        state.max_resources[i][j] = instance;                  
      }  
    } 
  fgets(comment, sizeof(comment), fp);     
  printf("Enter no. of instances of a resource already allocated to process:\n"); 
  for(i=0;i<num_processes;i++){
    printf("P[%d]\n",i);
    for(j=0;j<resource;j++){
      fscanf(fp, "%d",&instance);
      state.allocated[i][j] = instance;
      state.need[i][j] = state.max_resources[i][j] - state.allocated[i][j];
    }    
  }
  state_old = state;
  print_state(state_old, num_processes, resource);
  
  /*
   * Add a last row of 0 0 0 ...  to check if the current state is safe
   * Add a row with <process number> and additional resources it asks 
   * to check if granting these resources would possibly lead to deadlock
  */
  printf("Process asking resources:\n"); 
  scanf("%d", &i);
  for(j=0;j<resource;j++){
    scanf("%d",&instance);
    state.allocated[i][j] += instance;
    state.available[j] -= instance;
  }
  
  print_state(state, num_processes, resource);
   
  if(check_safe_state(state, num_processes, resource))
    printf("Safe - Resource assigned\n");
  else {
    printf("Unsafe - Resource assignement delayed\n");
    state = state_old;
  }
    
  return 0;
}

int
check_safe_state(State state, int num_processes, int resource){
int   i, j, k, count1, count2;

    k = 0;
    count1 = 0;
    count2 = 0;
    while(count1 != num_processes){
      count2=count1;
      for(i=0;i<num_processes;i++){
        for(j=0;j<resource;j++)
          if(state.need[i][j] <= state.available[j])
             k++;              
        if(k==resource  &&  state.completed[i]==0) {
          printf("P[%d] ",i);
          state.completed[i]=1;
          for(j=0;j<resource;j++)
            state.available[j] += state.allocated[i][j];
          count1++;
        }
        k=0;
      }
      
      if(count1==count2){
       printf("Unsafe\n");
       return 0;  
    }    
  }
  printf("\n");
  return 1;
}  

void
print_state(State state, int num_processes, int resource){
int   i, j;

    printf("State\n");
    printf("Process\t");
    printf("Allocated\t");
    printf("Max_res \t");
    printf("Available\n");
    for(i=0;i<num_processes;i++){
	  printf("%d\t", i);
	  for(j=0;j<resource;j++)
	    printf("%d ", state.allocated[i][j]);
	  printf("\t");
	  for(j=0;j<resource;j++)
	    printf("%d ", state.max_resources[i][j]);
	  printf("\t");	
	  if (i==0){
	    for(j=0;j<resource;j++)
	      printf("%d ", state.available[j]);
	  }
	  printf("\n");  
    }
  }    

int 
** mat_alloc(int r, int c){
int i;
int **v;

  v = (int **) malloc(r*sizeof(int *));
  for (i=0;i<r;i++)
    v[i] = (int *) calloc(c, sizeof(int));
  return v;
}      
                        
      
