#!/bin/bash

# Interactive input 

echo -n Insert a sentence: 

read w1 w2 others

echo Word 1 is: $w1
echo Word 2 is: $w2
echo The rest of the line is: $others

exit 0
