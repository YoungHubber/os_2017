#!/bin/bash

myVar="STRING"

echo $myVar
echo "$myVar"
echo '$myVar'
echo \$myVar

exit 0
