#!/bin/bash

echo "Process $0 is runnning"
echo "First argument: $1"
echo "Second argument: $2"
echo "Number of arguments $#"
echo "Argument list $*"
echo "Home directory $HOME"
echo "Path $PATH"

exit 0
