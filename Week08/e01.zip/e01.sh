#!/bin/bash

# This line is a comment

rm -rf ../newDir
mkdir ../newDir
cp * ../newDir/
ls ../newDir/

# 0 is TRUE in shell programming

exit 0
