#include <stdio.h>

#define VET_DIM_MAX 100

void inputVet (int *, int *);
void outputVet (int *, int);
